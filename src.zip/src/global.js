import { ref } from "vue";
import { reactive } from "vue";

const currUser = ref({});
export { currUser };
